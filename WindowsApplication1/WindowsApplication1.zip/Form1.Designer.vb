﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdValid = New System.Windows.Forms.Button()
        Me.cmdValid1 = New System.Windows.Forms.Button()
        Me.cmdNoSeparator = New System.Windows.Forms.Button()
        Me.cmdNoSelectStatement = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.cmdBadSelectStatement = New System.Windows.Forms.Button()
        Me.cmdValidNoMatches = New System.Windows.Forms.Button()
        Me.TextBoxWhere1 = New WindowsApplication1.TextBoxWhere()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdValid
        '
        Me.cmdValid.Location = New System.Drawing.Point(12, 55)
        Me.cmdValid.Name = "cmdValid"
        Me.cmdValid.Size = New System.Drawing.Size(156, 23)
        Me.cmdValid.TabIndex = 1
        Me.cmdValid.Text = "Valid 1"
        Me.cmdValid.UseVisualStyleBackColor = True
        '
        'cmdValid1
        '
        Me.cmdValid1.Location = New System.Drawing.Point(12, 84)
        Me.cmdValid1.Name = "cmdValid1"
        Me.cmdValid1.Size = New System.Drawing.Size(156, 23)
        Me.cmdValid1.TabIndex = 2
        Me.cmdValid1.Text = "Valid 2 with apostrophe"
        Me.cmdValid1.UseVisualStyleBackColor = True
        '
        'cmdNoSeparator
        '
        Me.cmdNoSeparator.Location = New System.Drawing.Point(12, 113)
        Me.cmdNoSeparator.Name = "cmdNoSeparator"
        Me.cmdNoSeparator.Size = New System.Drawing.Size(156, 23)
        Me.cmdNoSeparator.TabIndex = 3
        Me.cmdNoSeparator.Text = "No separator"
        Me.cmdNoSeparator.UseVisualStyleBackColor = True
        '
        'cmdNoSelectStatement
        '
        Me.cmdNoSelectStatement.Location = New System.Drawing.Point(12, 142)
        Me.cmdNoSelectStatement.Name = "cmdNoSelectStatement"
        Me.cmdNoSelectStatement.Size = New System.Drawing.Size(156, 23)
        Me.cmdNoSelectStatement.TabIndex = 4
        Me.cmdNoSelectStatement.Text = "No SELECT statement"
        Me.cmdNoSelectStatement.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 215)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(480, 131)
        Me.DataGridView1.TabIndex = 5
        '
        'cmdBadSelectStatement
        '
        Me.cmdBadSelectStatement.Location = New System.Drawing.Point(12, 171)
        Me.cmdBadSelectStatement.Name = "cmdBadSelectStatement"
        Me.cmdBadSelectStatement.Size = New System.Drawing.Size(156, 23)
        Me.cmdBadSelectStatement.TabIndex = 6
        Me.cmdBadSelectStatement.Text = "Invalid SELECT statement"
        Me.cmdBadSelectStatement.UseVisualStyleBackColor = True
        '
        'cmdValidNoMatches
        '
        Me.cmdValidNoMatches.Location = New System.Drawing.Point(183, 55)
        Me.cmdValidNoMatches.Name = "cmdValidNoMatches"
        Me.cmdValidNoMatches.Size = New System.Drawing.Size(156, 23)
        Me.cmdValidNoMatches.TabIndex = 7
        Me.cmdValidNoMatches.Text = "Valid no matches"
        Me.cmdValidNoMatches.UseVisualStyleBackColor = True
        '
        'TextBoxWhere1
        '
        Me.TextBoxWhere1.ColumnName = "supplier_name"
        Me.TextBoxWhere1.DataType = WindowsApplication1.DataTypes.[String]
        Me.TextBoxWhere1.Location = New System.Drawing.Point(12, 25)
        Me.TextBoxWhere1.Name = "TextBoxWhere1"
        Me.TextBoxWhere1.SelectStatement = "SELECT supplier_id,supplier_name,city,[state] FROM SomeTable"
        Me.TextBoxWhere1.Separator = Global.Microsoft.VisualBasic.ChrW(44)
        Me.TextBoxWhere1.Size = New System.Drawing.Size(240, 20)
        Me.TextBoxWhere1.TabIndex = 0
        Me.TextBoxWhere1.Text = "Google,Kimberly-Clarks,Tyson Foods"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(504, 349)
        Me.Controls.Add(Me.cmdValidNoMatches)
        Me.Controls.Add(Me.cmdBadSelectStatement)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.cmdNoSelectStatement)
        Me.Controls.Add(Me.cmdNoSeparator)
        Me.Controls.Add(Me.cmdValid1)
        Me.Controls.Add(Me.cmdValid)
        Me.Controls.Add(Me.TextBoxWhere1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBoxWhere1 As TextBoxWhere
    Friend WithEvents cmdValid As Button
    Friend WithEvents cmdValid1 As Button
    Friend WithEvents cmdNoSeparator As Button
    Friend WithEvents cmdNoSelectStatement As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents cmdBadSelectStatement As Button
    Friend WithEvents cmdValidNoMatches As Button
End Class
