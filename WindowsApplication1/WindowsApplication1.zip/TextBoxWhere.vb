﻿Imports System.ComponentModel
Public Enum DataTypes
    [String]
    [Integer]
    Datetime2
End Enum
Public Class TextBoxWhere
    Inherits TextBox

    <Category("Data"), Description("Column type for property ColumnName")>
    Public Property DataType As DataTypes

    Private mInClause As String
    <Browsable(False)>
    Public ReadOnly Property InClause As String
        Get
            Return mInClause
        End Get
    End Property
    Private mWhere As String
    Public ReadOnly Property Where As String
        Get
            Return mWhere
        End Get
    End Property
    Private mIsValid As Boolean
    <Browsable(False)>
    Public ReadOnly Property IsValid As Boolean
        Get
            Return mIsValid
        End Get
    End Property

    <Category("Data"), Description("Column name in table")>
    Public Property ColumnName As String
    <Category("Data"), Description("Char separator in Text property to split on")>
    Public Property Separator As Char
    <Category("Data"), Description("Valid SQL SELECT with no WHERE clause")>
    Public Property SelectStatement As String

    Public Sub CreateInClause()
        If Not String.IsNullOrWhiteSpace(Text) AndAlso Not String.IsNullOrWhiteSpace(SelectStatement) Then
            If Not String.IsNullOrWhiteSpace(ColumnName) AndAlso Not Separator = vbNullChar Then

                Dim splitTokensArray As String() = Text.Split(Separator)

                Dim sb As New Text.StringBuilder
                For Each item In splitTokensArray


                    Select Case DataType
                        Case DataTypes.String
                            sb.Append($"'{item.Replace("'", "''")}',")
                        Case DataTypes.Integer
                            sb.Append($"{item},")
                        Case DataTypes.Datetime2
                            sb.Append($"'{item}',")
                    End Select
                Next

                Dim joinedTokens As String = sb.ToString
                If joinedTokens.Last = "," Then
                    joinedTokens = joinedTokens.Substring(0, joinedTokens.Length - 1)
                End If

                Dim whereTokens = "(" & joinedTokens & ")"
                mWhere = whereTokens


                mInClause = $"{SelectStatement} WHERE {ColumnName} IN " & whereTokens
                mIsValid = True
            Else
                mIsValid = False
            End If
        Else
            mIsValid = False
        End If
    End Sub

End Class
