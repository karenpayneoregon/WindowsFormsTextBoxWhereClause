﻿Public Class Form1
    Private SelectStatement As String =
        "SELECT supplier_id,supplier_name,city,[state] FROM WhereInSimple"

    ''' <summary>
    ''' Simple, comma delimited, no apostrophe, column name specified
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmdValid_Click(sender As Object, e As EventArgs) Handles cmdValid.Click
        TextBoxWhere1.Text = "Google,Kimberly-Clarks,Tyson Foods"
        TextBoxWhere1.SelectStatement = SelectStatement
        TextBoxWhere1.Separator = ","c
        TextBoxWhere1.ColumnName = "supplier_name"
        TextBoxWhere1.CreateInClause()
        If TextBoxWhere1.IsValid Then
            PopulateDataDataGridView(TextBoxWhere1.InClause)
        Else
            DataGridView1.DataSource = Nothing
        End If
    End Sub
    Private Sub cmdValid1_Click_1(sender As Object, e As EventArgs) Handles cmdValid1.Click
        TextBoxWhere1.Text = "Google's,Kimberly-Clarks,Tyson Foods"
        TextBoxWhere1.SelectStatement = SelectStatement
        TextBoxWhere1.Separator = ","c
        TextBoxWhere1.ColumnName = "supplier_name"

        TextBoxWhere1.CreateInClause()
        If TextBoxWhere1.IsValid Then
            PopulateDataDataGridView(TextBoxWhere1.InClause)
        Else
            DataGridView1.DataSource = Nothing
        End If
    End Sub

    Private Sub cmdNoSeparator_Click(sender As Object, e As EventArgs) Handles cmdNoSeparator.Click
        TextBoxWhere1.Text = "Google's,Kimberly-Clarks,Tyson Foods"
        TextBoxWhere1.SelectStatement = SelectStatement
        TextBoxWhere1.Separator = Nothing
        TextBoxWhere1.ColumnName = "supplier_name"

        TextBoxWhere1.CreateInClause()
        If TextBoxWhere1.IsValid Then
            PopulateDataDataGridView(TextBoxWhere1.InClause)
        Else
            DataGridView1.DataSource = Nothing
            MessageBox.Show("Not configured correctly")
        End If
    End Sub

    Private Sub cmdNoSelectStatement_Click(sender As Object, e As EventArgs) Handles cmdNoSelectStatement.Click
        TextBoxWhere1.Text = ""
        TextBoxWhere1.SelectStatement = SelectStatement
        TextBoxWhere1.Separator = Nothing
        TextBoxWhere1.ColumnName = "supplier_name"

        TextBoxWhere1.CreateInClause()
        If TextBoxWhere1.IsValid Then
            PopulateDataDataGridView(TextBoxWhere1.InClause)
        Else
            DataGridView1.DataSource = Nothing
            MessageBox.Show("Not configured correctly")
        End If
    End Sub
    Private Sub cmdBadSelectStatement_Click(sender As Object, e As EventArgs) Handles cmdBadSelectStatement.Click
        TextBoxWhere1.Text = "SELECT id,supplier_name,city,[state] FROM WhereInSimple"
        TextBoxWhere1.SelectStatement = TextBoxWhere1.Text
        TextBoxWhere1.Separator = ","c
        TextBoxWhere1.ColumnName = "supplier_name"

        TextBoxWhere1.CreateInClause()
        If TextBoxWhere1.IsValid Then
            PopulateDataDataGridView(TextBoxWhere1.InClause)

        Else
            DataGridView1.DataSource = Nothing
            MessageBox.Show("Not configured correctly")
        End If
    End Sub
    Private Sub cmdValidNoMatches_Click(sender As Object, e As EventArgs) Handles cmdValidNoMatches.Click
        TextBoxWhere1.Text = "Starbucks,Clarks,Bad Foods"
        TextBoxWhere1.SelectStatement = SelectStatement
        TextBoxWhere1.Separator = ","c
        TextBoxWhere1.ColumnName = "supplier_name"
        TextBoxWhere1.CreateInClause()
        If TextBoxWhere1.IsValid Then
            PopulateDataDataGridView(TextBoxWhere1.InClause)
            If DataGridView1.Rows.Count = 1 AndAlso CType(DataGridView1.DataSource, DataTable).Rows.Count = 0 Then
                MessageBox.Show($"No matches for column {TextBoxWhere1.ColumnName} using{Environment.NewLine}{TextBoxWhere1.Where}")
            End If
        Else
            DataGridView1.DataSource = Nothing
        End If
    End Sub
    Public Sub PopulateDataDataGridView(ByVal SelectStatement As String)
        Dim dt As New DataTable
        Dim databaseServer As String = "KARENS-PC"
        Dim defaultCatalog As String = "ForumExamples"
        Using cn As New SqlClient.SqlConnection
            cn.ConnectionString = $"Data Source={databaseServer};Initial Catalog={defaultCatalog};Integrated Security=True"
            Using cmd As New SqlClient.SqlCommand With {.Connection = cn}
                cmd.CommandText = SelectStatement
                cn.Open()
                Try
                    dt.Load(cmd.ExecuteReader)
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
            End Using
        End Using
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetCueText(TextBoxWhere1, "Enter valid SQL")
    End Sub


End Class
